# -*- coding: utf-8 -*-
import scrapy
from scrapy import FormRequest

from cansoCrawler.items.items import IranpelakCarItem


class IranpelakSpider(scrapy.Spider):
    name = 'iranpelak'
    allowed_domains = ['iranpelak.com']
    start_urls = ['https://iranpelak.com/car-search']
    url = 'https://iranpelak.com/faces/root/car-search.xhtml'
    token = ""
    _pages = 9

    def parse(self, response):
        self.token = response.css('input[name="javax.faces.ViewState"]::attr(value)').get()
        self.logger.info(f"token: {self.token}")
        self.logger.info(f"form data: {self.create_form_data(1)}")

        yield FormRequest(url=self.url, method="POST", formdata=self.create_form_data(1), callback=self.parse_ads,
                          headers=self.headers)

    def parse_ads(self, response, page=2):
        # [href[:href.find('jsessionid') - 1] for href in (response.css('a::attr(href)').getall()) if 'ad-' in href]
        href_list = [f"https://iranpelak.com{href}" for href in (response.css('a::attr(href)').getall()) if
                     'ad-' in href]
        self.logger.info(f"href_list length: {len(href_list)}")
        self.logger.info(f"href_list: {href_list}")

        yield from response.follow_all(href_list, callback=self.parse_ad, headers=self.headers)

        if page <= self._pages:
            yield FormRequest(url=self.url, method="POST", formdata=self.create_form_data(page),
                              callback=self.parse_ads,
                              headers=self.headers, cb_kwargs={"page": page + 1})

    def parse_ad(self, response):
        self.logger.info(f"extract for: {response.request.url.split('/')[-1]}")
        item = IranpelakCarItem()
        item.extract(response)
        return item

    def create_form_data(self, page):
        return {
            "form": "form",
            "j_idt260": "NEWEST",
            "search-by-brand-input-textValue": "",
            "search-by-brand-input-textInput": "",
            "search-by-province-input-textValue": "",
            "search-by-province-input-textInput": "",
            "price-from-select-menu-has-options": "P_0",
            "price-to-select-menu-has-options": "P_500_MILLION_TOMANS_PLUS",
            "release-year-from-select-menu": "LESY_THAN_1979_1358",
            "release-year-to-select-menu": "Y_2021_1400",
            "odometer-from-select-menu-has-options": "KM_0",
            "odometer-to-select-menu-has-options": "KM_100000_PLUS",
            "name_input_text": "",
            "mobile_number_activation_input_text":"",
            "modal_activation_code_input_text":"",
            "mobile_number_input_text": "",
            "password_input_text": "",
            "confirm_password_input_text": "",
            "mobile_number_sign_in_input_text": "",
            "password_sign_in_input_text": "",
            "modal - mobile_number_input_text": "",
            "javax.faces.ViewState": f"{self.token}",
            "javax.faces.source": "j_idt382",
            "javax.faces.partial.event": "rich:datascroller:onscroll",
            "javax.faces.partial.execute": "j_idt382 @ component",
            "javax.faces.partial.render": "@component",
            "j_idt382:page": f"{page}",
            "org.richfaces.ajax.component": "j_idt382",
            "j_idt382": "j_idt382",
            "rfExt": "null",
            "AJAX:EVENTS_COUNT": "1",
            "javax.faces.partial.ajax": "true"
        }

    headers = {
        "Content-type": "application/x-www-form-urlencoded;charset=UTF-8",
        "Cookie": "JSESSIONID=c34a69b3e1f3a061f40f0eb89a31; _ga=GA1.2.361324935.1634708277; _gid=GA1.2.1924173164.1634708277; __asc=b89a42bd17c9c34caaef691c53b; __auc=b89a42bd17c9c34caaef691c53b; _gat=1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36 Edg/94.0.992.50"
    }
