local_db = {
    "database": "ganje",
    "user": "ganje",
    "password": "ganje",
    "host": "10.10.1.31",
    "port": 5432
}
server_db = {
    "database": "ganje",
    "user": "ganje",
    "password": "ganje",
    "host": "10.10.1.31",
    "port": 5432
}
